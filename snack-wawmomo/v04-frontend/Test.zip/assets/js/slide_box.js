$(function(){
    
    let a_in_slide_box = $(".a_in_slide_box");
    let a_out_slide_box = $(".a_out_slide_box");
    
    let slide_box = $(".slide_box");


    
    
    a_in_slide_box.click(function(){
        slide_box.addClass("show").removeClass("hide")
    });
    a_out_slide_box.click(function(){
        slide_box.addClass("hide").removeClass("show")
    });
})